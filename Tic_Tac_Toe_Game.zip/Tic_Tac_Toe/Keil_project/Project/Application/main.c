//Team :	1. Vishwajeetsinh Varnamiya
//			2. Sai Kashyap Kurella
//			3. Zeel Lia

//--------------------------------------------------------
// Application demonstrator: Tic Tac Toe game
//--------------------------------------------------------

#include "EDK_CM0.h"
#include "core_cm0.h"
#include "edk_driver.h"
#include "edk_api.h"
#include <stdio.h>

// Game region
#define left_boundary 5
#define right_boundary 93
#define top_boundary 5
#define bottom_boundary 114
#define boundary_thick 1

// CENTER OF BLOCK COORDINATES
#define BLOCK_X1 (top_boundary + boundary_thick + 14)
#define BLOCK_X2 (top_boundary + boundary_thick * 2 + 28 + 14)
#define BLOCK_X3 (top_boundary + boundary_thick * 3 + 28 * 2 + 14)

#define BLOCK_Y1 (left_boundary + boundary_thick + 17)
#define BLOCK_Y2 (left_boundary + boundary_thick * 2 + 35 + 17)
#define BLOCK_Y3 (left_boundary + boundary_thick * 3 + 35 * 2 + 17)

// Global variables
static char key;
int counter;
int turn;
int player;
int Array[9], EMPTY[9];

//---------------------------------------------
// Game
//---------------------------------------------

void Game_Init(void)
{
	// Draw a game region
	clear_screen();

	// VERTICAL LINES
	rectangle(left_boundary, top_boundary, left_boundary + boundary_thick, bottom_boundary, GREEN);															// 1
	rectangle(left_boundary + boundary_thick + 28, top_boundary, left_boundary + boundary_thick + 28 + boundary_thick, bottom_boundary, GREEN);				// 2
	rectangle(left_boundary + (boundary_thick + 28) * 2, top_boundary, left_boundary + (boundary_thick + 28) * 2 + boundary_thick, bottom_boundary, GREEN); // 3
	rectangle(right_boundary, top_boundary, right_boundary + boundary_thick, bottom_boundary + boundary_thick, GREEN);										// 4

	// HORIZONTAL LINES
	rectangle(left_boundary, top_boundary, right_boundary, top_boundary + boundary_thick, GREEN);														  // 1
	rectangle(left_boundary, top_boundary + boundary_thick + 35, right_boundary, top_boundary + boundary_thick + 35 + boundary_thick, GREEN);			  // 2
	rectangle(left_boundary, top_boundary + (boundary_thick + 35) * 2, right_boundary, top_boundary + (boundary_thick + 35) * 2 + boundary_thick, GREEN); // 3
	rectangle(left_boundary, bottom_boundary, right_boundary, bottom_boundary + boundary_thick, GREEN);													  // 4

	// Initialise counter
	counter = 0;

	// Initialise turn
	turn = RED;

	// Initialise player
	player = 1;

	// Initialise data
	for (int i = 0; i < 9; i++)
	{
		Array[i] = 1;
		EMPTY[i] = 1;
	}

	// Initialise timer (load value, prescaler value, mode value)
	timer_init(Timer_Load_Value_For_One_Sec, Timer_Prescaler, 1);
	timer_enable();

	// Print instructions
	// Starting

	printf("-------TIC-TAC-TOE GAME -----\n");
	printf("\nPlayer-1 .. RED");
	printf("\nPlayer-2 ...GREEN");
	printf("\nPlayer-1=R && Player-2=G ");
	printf("\n----- CONTROLS ------------");
	printf("\nKeyboard 'R' ---> Soft Reset");
	printf("\n-Hit keys from the Num Pad-");
	printf("\n  ------ ------ ------");
	printf("\n |   1  |   2  |  3   |");
	printf("\n  ------ ------ ------");
	printf("\n |   4  |   5  |  6   |");
	printf("\n  ------ ------ ------");
	printf("\n |   7  |   8  |  9   |");
	printf("\n  ------ ------ ------\n");
	printf("\n----- CAUTION ------------");
	printf("\nTo run the game, make sure:");
	printf("\n*UART terminal is activated");
	printf("\n*UART baud rare:  19200 bps");
	printf("\n*Keyboard is in lower case");
	printf("\n--------------------------\n");
	printf("\nPlease take your turn");
	printf("\n--> Player-1 \n");

	while (KBHIT() == 0);
	NVIC_EnableIRQ(UART_IRQn);
}

void Game_Close(void)
{
	clear_screen();
	printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"); // flush screen
	printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
	NVIC_DisableIRQ(UART_IRQn);
}

int GameOver(void)
{
	char key;
	printf("\n    Game Over\n");
	printf("\nPress 'r' to replay");
	printf("\nPress 'q' to quit");
	

	while (1)
	{
		while (KBHIT() == 0)
			;
		key = UartGetc();
		if (key == RESET)
		{
			return 1;
		}
		else if (key == QUIT)
		{
			return 0;
		}
		else
			printf("\nInvalid input");
	}
}

//---------------------------------------------
// UART ISR -- used to input commands
//---------------------------------------------

void UART_ISR(void)
{

	key = UartGetc();

	if ((key == ONE) && (EMPTY[0] == 1))
	{ // 1
		counter++;
		if (player == 1)
			circle(BLOCK_X1, BLOCK_Y1, turn);
		else
			cross(BLOCK_X1, BLOCK_Y1, turn);
		EMPTY[0] = 0;
		Array[0] = turn;
	}
	else if (key == TWO && (EMPTY[1] == 1))
	{ // 2
		counter++;
		if (player == 1)
			circle(BLOCK_X2, BLOCK_Y1, turn);
		else
			cross(BLOCK_X2, BLOCK_Y1, turn);
		EMPTY[1] = 0;
		Array[1] = turn;
	}
	else if (key == THREE && (EMPTY[2] == 1))
	{ // 3
		counter++;
		if (player == 1)
			circle(BLOCK_X3, BLOCK_Y1, turn);
		else
			cross(BLOCK_X3, BLOCK_Y1, turn);
		EMPTY[2] = 0;
		Array[2] = turn;
	}
	else if (key == FOUR && (EMPTY[3] == 1))
	{ // 4
		counter++;
		if (player == 1)

			circle(BLOCK_X1, BLOCK_Y2, turn);
		else
			cross(BLOCK_X1, BLOCK_Y2, turn);
		EMPTY[3] = 0;
		Array[3] = turn;
	}
	else if (key == FIVE && (EMPTY[4] == 1))
	{ // 5
		counter++;
		if (player == 1)
			circle(BLOCK_X2, BLOCK_Y2, turn);
		else
			cross(BLOCK_X2, BLOCK_Y2, turn);
		EMPTY[4] = 0;
		Array[4] = turn;
	}
	else if (key == SIX && (EMPTY[5] == 1))
	{ // 6
		counter++;
		if (player == 1)
			circle(BLOCK_X3, BLOCK_Y2, turn);
		else
			cross(BLOCK_X3, BLOCK_Y2, turn);
		EMPTY[5] = 0;
		Array[5] = turn;
	}
	else if (key == SEVEN && (EMPTY[6] == 1))
	{ // 7
		counter++;
		if (player == 1)
			circle(BLOCK_X1, BLOCK_Y3, turn);
		else
			cross(BLOCK_X1, BLOCK_Y3, turn);
		EMPTY[6] = 0;
		Array[6] = turn;
	}
	else if (key == EIGHT && (EMPTY[7] == 1))
	{ // 8
		counter++;
		if (player == 1)
			circle(BLOCK_X2, BLOCK_Y3, turn);
		else
			cross(BLOCK_X2, BLOCK_Y3, turn);
		EMPTY[7] = 0;
		Array[7] = turn;
	}
	else if (key == NINE && (EMPTY[8] == 1))
	{ // 9
		counter++;
		if (player == 1)
			circle(BLOCK_X3, BLOCK_Y3, turn);
		else
			cross(BLOCK_X3, BLOCK_Y3, turn);
		EMPTY[8] = 0;
		Array[8] = turn;
	}
	else
		printf("\nInvalid key!!! \nPlease enter from 1 to 9 digit keys");

	// Check Win Condition
	if ((Array[0] == RED && Array[1] == RED && Array[2] == RED) || (Array[0] == GREEN && Array[1] == GREEN && Array[2] == GREEN))
	{ // 0 1 2
		printf("\nPlayer-%d Won the Match", player);
		if (GameOver() == 0)
			Game_Close();
		else
			Game_Init();
	}
	else if ((Array[3] == RED && Array[4] == RED && Array[5] == RED) || (Array[3] == GREEN && Array[4] == GREEN && Array[5] == GREEN))
	{ // 3 4 5
		printf("\nPlayer-%d Won the Match", player);
		if (GameOver() == 0)
			Game_Close();
		else
			Game_Init();
	}
	else if ((Array[6] == RED && Array[7] == RED && Array[8] == RED) || (Array[6] == GREEN && Array[7] == GREEN && Array[8] == GREEN))
	{ // 6 7 8
		printf("\nPlayer-%d Won the Match", player);
		if (GameOver() == 0)
			Game_Close();
		else
			Game_Init();
	}
	else if ((Array[0] == RED && Array[3] == RED && Array[6] == RED) || (Array[0] == GREEN && Array[3] == GREEN && Array[6] == GREEN))
	{ // 0 3 6
		printf("\nPlayer-%d Won the Match", player);
		if (GameOver() == 0)
			Game_Close();
		else
			Game_Init();
	}
	else if ((Array[1] == RED && Array[4] == RED && Array[7] == RED) || (Array[1] == GREEN && Array[4] == GREEN && Array[7] == GREEN))
	{ // 1 4 7
		printf("\nPlayer-%d Won the Match", player);
		if (GameOver() == 0)
			Game_Close();
		else
			Game_Init();
	}
	else if ((Array[2] == RED && Array[4] == RED && Array[6] == RED) || (Array[2] == GREEN && Array[4] == GREEN && Array[6] == GREEN))
	{ // 2 4 6
		printf("\nPlayer-%d Won the Match", player);
		if (GameOver() == 0)
			Game_Close();
		else
			Game_Init();
	}
	else if ((Array[1] == RED && Array[4] == RED && Array[8] == RED) || (Array[1] == GREEN && Array[4] == GREEN && Array[8] == GREEN))
	{ // 1 4 8
		printf("\nPlayer-%d Won the Match", player);
		if (GameOver() == 0)
			Game_Close();
		else
			Game_Init();
	}
	else if ((Array[0] == RED && Array[4] == RED && Array[8] == RED) || (Array[0] == GREEN && Array[4] == GREEN && Array[8] == GREEN))
	{ // 0 4 8
		printf("\nPlayer-%d Won the Match", player);
		if (GameOver() == 0)
			Game_Close();
		else
			Game_Init();
	}
	else if (counter == 9)
	{
		printf("\nGame Draw");
		if (GameOver() == 0)
			Game_Close();
		else
			Game_Init();
	}

	if (turn == RED)
		turn = GREEN;
	else
		turn = RED;

	if (player == 1)
	{
		player = 2;
		printf("\n--> Player-%d \n", player);
	}
	else
	{
		player = 1;
		printf("\n--> Player-%d \n", player);
	}
}

void Timer_ISR(void){
	
}

//---------------------------------------------
// Main Function
//---------------------------------------------

int main(void)
{

	// Initialise the system
	SoC_init();
	// Initialise the game
	Game_Init();

	// Go to sleep mode and wait for interrupts
	while (1)
		__WFI();
}